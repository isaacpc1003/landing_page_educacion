import React, { useEffect, useState } from 'react';
import './BenefitsSection.css';
import video1 from './assets/videos/video1.mp4';
import video2 from './assets/videos/video2.mp4';
import video3 from './assets/videos/video3.mp4';

function BenefitsSection() {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <section id="benefits" className="benefits">
      <div className="container">
        <div className="benefit-item fade-in-element">
          <div className="benefit-content">
            <h3>Aprendizaje Personalizado</h3>
            <p>La IA adapta el contenido educativo según las necesidades de cada estudiante, garantizando un aprendizaje más efectivo.</p>
          </div>
          <div className="video-gradient-container">
            <div className="video-placeholder">
              <video src={video1} autoPlay loop muted></video>
            </div>
            <div className="video-gradient video-gradient-left"></div>
          </div>
        </div>
        {isMobile ? (
          <>
            <div className="benefit-item fade-in-element">
              <div className="benefit-content">
                <h3>Automatización de Tareas</h3>
                <p>Automatiza las tareas administrativas y de evaluación, permitiendo a los educadores centrarse en lo que realmente importa: enseñar.</p>
              </div>
              <div className="video-gradient-container">
                <div className="video-placeholder">
                  <video src={video2} autoPlay loop muted></video>
                </div>
                <div className="video-gradient video-gradient-left"></div>
              </div>
            </div>
            <div className="benefit-item fade-in-element">
              <div className="benefit-content">
                <h3>Interacción Mejorada</h3>
                <p>El chatbot facilita la comunicación entre estudiantes y profesores, proporcionando respuestas rápidas y recursos adicionales.</p>
              </div>
              <div className="video-gradient-container">
                <div className="video-placeholder">
                  <video src={video3} autoPlay loop muted></video>
                </div>
                <div className="video-gradient video-gradient-right"></div>
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="benefit-item fade-in-element">
              <div className="video-gradient-container">
                <div className="video-placeholder">
                  <video src={video2} autoPlay loop muted></video>
                </div>
                <div className="video-gradient video-gradient-right"></div>
              </div>
              <div className="benefit-content">
                <h3>Automatización de Tareas</h3>
                <p>Automatiza las tareas administrativas y de evaluación, permitiendo a los educadores centrarse en lo que realmente importa: enseñar.</p>
              </div>
            </div>
            <div className="benefit-item fade-in-element">
              <div className="benefit-content">
                <h3>Interacción Mejorada</h3>
                <p>El chatbot facilita la comunicación entre estudiantes y profesores, proporcionando respuestas rápidas y recursos adicionales.</p>
              </div>
              <div className="video-gradient-container">
                <div className="video-placeholder">
                  <video src={video3} autoPlay loop muted></video>
                </div>
                <div className="video-gradient video-gradient-left"></div>
              </div>
            </div>
          </>
        )}
      </div>
    </section>
  );
}

export default BenefitsSection;
